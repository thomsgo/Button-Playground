//: A UIKit based Playground for presenting user interface
import UIKit
import PlaygroundSupport

class MyViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    var collectionView: UICollectionView? // ! or ? ????
    var headerView: UIView!
    
    var cellId = "MyCell"
    
    override func viewDidLoad() {
        print("viewDidLoad Start")
        super.viewDidLoad()
        self.view.backgroundColor = .white
        
        setupHeaderView()
        setupCollectionView()
        //view.addSubview(headerView)
        //view.addSubview(collectionView!)

        setupStack()

        print("viewDidLoad End")
    }
    
    func setupCollectionView () {
    
        let outerFrame:CGRect = CGRect(x: 10, y: 200, width: 355, height: 250)
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        layout.itemSize = CGSize(width: outerFrame.width, height: 80)
        
        collectionView = UICollectionView(frame: outerFrame, collectionViewLayout: layout)
        collectionView?.delegate = self
        collectionView?.dataSource = self
        collectionView?.backgroundColor = .yellow
        collectionView?.isUserInteractionEnabled = true
        collectionView?.register(FreelancerCell.self, forCellWithReuseIdentifier: cellId)
    }
    func setupHeaderView() {
        headerView = UIView()
        //headerView = UIView()
        headerView.backgroundColor = .lightGray
        
        headerView.addSubview(titleButton)
        titleButton.centerXAnchor.constraint(equalTo: headerView.centerXAnchor).isActive = true
        titleButton.centerYAnchor.constraint(equalTo: headerView.centerYAnchor).isActive = true
        titleButton.widthAnchor.constraint(equalTo: headerView.widthAnchor, multiplier: 0.5).isActive = true
        titleButton.heightAnchor.constraint(equalTo: headerView.heightAnchor, multiplier: 0.5).isActive = true
    }
    
    // Vertical Stack of Cells
    func setupStack() {
        print("setupStack")
        let stackView = UIStackView(arrangedSubviews: [collectionView!, headerView])
        //let stackView = UIStackView(arrangedSubviews: [collectionView!])
        stackView.axis = .vertical
        stackView.distribution = .fillEqually
        stackView.alignment = .fill
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false
    
        view.addSubview(stackView)
        
        // autolayout the stack view - !!This has to be after addSubView!!
        let sH = NSLayoutConstraint.constraints(withVisualFormat: "H:|-20-[stackView]-20-|", options: NSLayoutFormatOptions(rawValue:0), metrics: nil, views: ["stackView":stackView])
        let sV = NSLayoutConstraint.constraints(withVisualFormat: "V:|-30-[stackView]-30-|", options: NSLayoutFormatOptions(rawValue:0), metrics: nil, views: ["stackView":stackView])
        view.addConstraints(sH)
        view.addConstraints(sV)
}
    
    let titleButton: UIButton = {
        let button = UIButton()
        //button.frame = CGRect(x: 10, y: 10, width: 200, height: 100)
        button.setTitle("New Title Button", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        button.layer.borderColor = UIColor.blue.cgColor
        button.layer.borderWidth = 2.0
        button.backgroundColor = .cyan
        button.isUserInteractionEnabled = true
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(titleAction), for: UIControlEvents.touchUpInside)
        return button
    }()

    // This determines how many cells are added and how many calls are made to addViews
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath)->UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! FreelancerCell
        print("dequeueReusableCell \(indexPath.row)")
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("didSelectItemAt : \(indexPath.item + 1)")
    }
    private func collectionView(_ collectionView: FreelancerCell, canFocusItemAt indexPath: IndexPath) -> Bool {
        print("canFocusItemAt Pressed : \(indexPath.item + 1)")
        return false
    }

    @objc func titleAction(sender: UIButton!) {
        print("Title Tapped")
    }
}

class FreelancerCell: UICollectionViewCell {

    // Message Button
    let messageButton: UIButton = {
        print("messageButton")
        let button = UIButton()
        button.setTitle("Message", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(buttonAction), for: UIControlEvents.allTouchEvents)
        return button
    }()

    //Initialize and add buttons
    override init(frame: CGRect) {
        super.init(frame: frame)
        print("FreelancerCell init")
        
        print("Start FreelancerCell addViews")
        backgroundColor = UIColor.green
        
        addSubview(messageButton)
        isUserInteractionEnabled = true
        
        messageButton.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -10).isActive = true
        messageButton.trailingAnchor.constraint(equalTo: trailingAnchor,constant: 0).isActive = true
        messageButton.widthAnchor.constraint(equalTo: widthAnchor).isActive = true
        
        print("End FreelancerCell addViews")
    }
 
    @objc func buttonAction(sender: UIButton!) {
        print("Button tapped")
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

PlaygroundPage.current.liveView = MyViewController()

